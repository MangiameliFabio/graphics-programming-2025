#include "MeshRaytracingApplication.h"

int main()
{
    MeshRaytracingApplication raytracingApplication;
    return raytracingApplication.Run();
}
